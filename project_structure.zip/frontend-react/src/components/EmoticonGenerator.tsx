
import React, { useState } from 'react';
import axios from 'axios';

const EmoticonGenerator: React.FC = () => {
    const [emoticon, setEmoticon] = useState<string>('');

    const fetchEmoticon = async () => {
        const response = await axios.get<{ emoticon: string }>('/generate-emoticon');
        setEmoticon(response.data.emoticon);
    };

    return (
        <div>
            <button onClick={fetchEmoticon}>Generar Emoticono</button>
            <p>{emoticon}</p>
        </div>
    );
};

export default EmoticonGenerator;
