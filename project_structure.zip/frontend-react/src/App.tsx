
import React from 'react';
import EmoticonGenerator from './components/EmoticonGenerator';
import UserForm from './components/UserForm';

const App: React.FC = () => {
    return (
        <div>
            <h1>SubMakeWeb</h1>
            <p>Juegos, apps, Eventos de Minecraft Bedrock, Buscar trabajadores</p>
            <EmoticonGenerator />
            <UserForm />
        </div>
    );
};

export default App;
